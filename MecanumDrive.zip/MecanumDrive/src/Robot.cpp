#include <iostream>
#include <memory>
#include <string>
#include <Joystick.h>
#include <SampleRobot.h>
#include <SmartDashboard/SendableChooser.h>
#include <SmartDashboard/SmartDashboard.h>
#include <robotDrive.h>
#include <Timer.h>
#include <VictorSP.h>
#include <SpeedController.h>
/**
 * This is a demo program showing the use of the robotDrive class.
 * The SampleRobot class is the base of a robot application that will
 * automatically call your Autonomous and OperatorControl methods at the right
 * time as controlled by the switches on the driver station or the field
 * controls.
 *
 * WARNING: While it may look like a good choice to use for your code if you're
 * inexperienced, don't. Unless you know what you are doing, complex code will
 * be much more difficult under this system. Use IterativeRobot or Command-Based
 * instead if you're new.
 */
class Robot: public frc::SampleRobot {
private:
	Joystick *stick; // only joystick
	frc::SendableChooser<std::string> chooser;
	const std::string autoNameDefault = "Default";
	const std::string autoNameCustom = "My Auto";
	/*VictorSP *lf_motor ; rf_motor, *lr_motor, *rr_motor;*/
	static constexpr int frontRightChannel = 1;
	static constexpr int frontLeftChannel = 2;
	static constexpr int rearLeftChannel = 3;
	static constexpr int rearRightChannel = 4;

	RobotDrive *robotDrive = new RobotDrive (frontLeftChannel, rearLeftChannel, frontRightChannel, rearRightChannel);
	// robot drive system
	// Update every 0.005 seconds/5 milliseconds.
	static constexpr double kUpdatePeriod = 0.005;

public:
	Robot() {
		//Note SmartDashboard is not initialized here, wait until RobotInit to make SmartDashboard calls
		robotDrive->SetExpiration(0.1); //make sure this is a robotDrive use
		//lf_motor = new VictorSP(1);
		/*rf_motor = new VictorSP(2);
		lr_motor = new VictorSP(3);
		rr_motor = new VictorSP(4);
		*/
		stick = new Joystick(0);
	}

	void Disabled()
	{
		while(IsDisabled())
		{

		}
	}

	void RobotInit() {
		chooser.AddDefault(autoNameDefault, autoNameDefault);
		chooser.AddObject(autoNameCustom, autoNameCustom);
		frc::SmartDashboard::PutData("Auto Modes", &chooser);
	}



	/*
	 * This autonomous (along with the chooser code above) shows how to select
	 * between different autonomous modes using the dashboard. The sendable
	 * chooser code works with the Java SmartDashboard. If you prefer the
	 * LabVIEW Dashboard, remove all of the chooser code and uncomment the
	 * GetString line to get the auto name from the text box below the Gyro.
	 *
	 * You can add additional auto modes by adding additional comparisons to the
	 * if-else structure below with additional strings. If using the
	 * SendableChooser make sure to add them to the chooser code above as well.
	 */
	void Autonomous() {
		auto autoSelected = chooser.GetSelected();
		// std::string autoSelected = frc::SmartDashboard::GetString("Auto Selector", autoNameDefault);
		std::cout << "Auto selected: " << autoSelected << std::endl;

		if (autoSelected == autoNameCustom) {
			// Custom Auto goes here
			std::cout << "Running custom Autonomous" << std::endl;
			robotDrive->SetSafetyEnabled(false);
			robotDrive->MecanumDrive_Cartesian(0.0,0.0,0.5,0.0); // spin at half speed
			frc::Wait(2.0);                // for 2 seconds
			robotDrive->MecanumDrive_Cartesian(0.0,0.0,0.0,0.0);  // stop robot
		} else {
			// Default Auto goes here
			std::cout << "Running default Autonomous" << std::endl;
			robotDrive->SetSafetyEnabled(false);
			robotDrive->Drive(-0.5, 0.0); // drive forwards half speed
			frc::Wait(2.0);                // for 2 seconds
			robotDrive->Drive(0.0, 0.0);  // stop robot
		}
	}

	/*
	 * Runs the motors with arcade steering.
	 */
	void OperatorControl() override {
		robotDrive->SetSafetyEnabled(true);
		while (IsOperatorControl() && IsEnabled()) {
			// drive with arcade style (use right stick)
			robotDrive->MecanumDrive_Cartesian(stick->GetX(), stick->GetY(), stick->GetTwist());
			//fl_motor -> Set(stick.GetRawAxis(0));
			// wait for a motor update time
			frc::Wait(kUpdatePeriod);
		}
	}

	/*
	 * Runs during test mode
	 */
	void Test() override {

	}
};
START_ROBOT_CLASS(Robot)
